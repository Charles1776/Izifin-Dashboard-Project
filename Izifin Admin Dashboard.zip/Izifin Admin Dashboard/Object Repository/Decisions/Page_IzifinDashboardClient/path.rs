<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>path</name>
   <tag></tag>
   <elementGuidId>daf61611-3e40-47af-a3fe-4c4df56fa3ab</elementGuidId>
   <selectorCollection>
      <entry>
         <key>CSS</key>
         <value>svg.mat-paginator-icon > path</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>path</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>d</name>
      <type>Main</type>
      <value>M18.41 16.59L13.82 12l4.59-4.59L17 6l-6 6 6 6zM6 6h2v12H6z</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/app-layout[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;wrapper__layout&quot;]/div[@class=&quot;wrapper__layout--content&quot;]/app-layout[@class=&quot;ng-star-inserted&quot;]/app-products[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;wrapper mt-5&quot;]/div[@class=&quot;card analytics-card&quot;]/div[@class=&quot;card-body ps-5 pe-5&quot;]/div[@class=&quot;mat-elevation-z8 user-table&quot;]/mat-paginator[@class=&quot;mat-paginator&quot;]/div[@class=&quot;mat-paginator-outer-container&quot;]/div[@class=&quot;mat-paginator-container&quot;]/div[@class=&quot;mat-paginator-range-actions&quot;]/button[@class=&quot;mat-focus-indicator mat-tooltip-trigger mat-paginator-navigation-first mat-icon-button mat-button-base ng-star-inserted&quot;]/span[@class=&quot;mat-button-wrapper&quot;]/svg[@class=&quot;mat-paginator-icon&quot;]/path[1]</value>
   </webElementProperties>
</WebElementEntity>
