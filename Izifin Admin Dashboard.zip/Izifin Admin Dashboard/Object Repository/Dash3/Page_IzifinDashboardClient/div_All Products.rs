<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_All Products</name>
   <tag></tag>
   <elementGuidId>a8a58da2-e86e-4895-a88b-d8eb7c3e6dd7</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>(.//*[normalize-space(text()) and normalize-space(.)='Demographic Analytics'])[1]/following::div[4]</value>
      </entry>
      <entry>
         <key>CSS</key>
         <value></value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>true</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>me-2 flex-grow-1 text-start fw-normal</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>All Products</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;mat-typography&quot;]/app-root[1]/app-layout[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;wrapper&quot;]/div[@class=&quot;wrapper__layout&quot;]/div[@class=&quot;wrapper__layout--content&quot;]/app-overview[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;overview-container&quot;]/section[@class=&quot;section_2&quot;]/div[@class=&quot;row gy-4 gx-2&quot;]/div[@class=&quot;analytics-card card col-12 ng-star-inserted&quot;]/app-schema-item[1]/app-chart[@class=&quot;ng-star-inserted&quot;]/div[@class=&quot;card-body p-3 p-md-5&quot;]/div[1]/app-filters[@class=&quot;flex-grow-1&quot;]/div[@class=&quot;d-flex filters horizontal justify-content-between&quot;]/app-products-selector[@class=&quot;ng-star-inserted&quot;]/app-selector[1]/div[1]/button[@class=&quot;mat-focus-indicator mat-menu-trigger filter_input mat-button mat-button-base&quot;]/span[@class=&quot;mat-button-wrapper&quot;]/div[@class=&quot;d-flex align-items-center&quot;]/div[@class=&quot;me-2 flex-grow-1 text-start fw-normal&quot;]</value>
   </webElementProperties>
   <webElementXpaths>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demographic Analytics'])[1]/following::div[4]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Accepts'])[1]/following::div[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Demographics'])[1]/preceding::div[8]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:neighbor</name>
      <type>Main</type>
      <value>(.//*[normalize-space(text()) and normalize-space(.)='Acceptance Rate'])[1]/preceding::div[11]</value>
   </webElementXpaths>
   <webElementXpaths>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath:position</name>
      <type>Main</type>
      <value>//div[4]/app-schema-item/app-chart/div/div/app-filters/div/app-products-selector/app-selector/div/button/span/div/div</value>
   </webElementXpaths>
</WebElementEntity>
