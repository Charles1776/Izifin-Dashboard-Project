<?xml version="1.0" encoding="UTF-8"?>
<TestSuiteEntity>
   <description></description>
   <name>Admin Dashboard Regression</name>
   <tag></tag>
   <isRerun>false</isRerun>
   <mailRecipient></mailRecipient>
   <numberOfRerun>0</numberOfRerun>
   <pageLoadTimeout>30</pageLoadTimeout>
   <pageLoadTimeoutDefault>true</pageLoadTimeoutDefault>
   <rerunFailedTestCasesOnly>false</rerunFailedTestCasesOnly>
   <rerunImmediately>false</rerunImmediately>
   <testSuiteGuid>0d777752-dc7a-473d-9269-e9609aaf9e21</testSuiteGuid>
   <testCaseLink>
      <guid>315f598f-7f1a-45a6-8091-5018377e405e</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Test Cases/Invalid Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>aff3312b-266e-4273-b20a-d6e486821c46</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Test Cases/Invalid Username</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>ac6e57ca-2dff-4536-ba67-9b3eedc02788</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Test Cases/Retrieve Password</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>a8e60d61-02d4-4fee-84ad-f6bb8139d69f</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Login Test Cases/Login</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>7ec9b706-91b9-4c9c-ba82-6be990204a4a</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Dashboard</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>bf043055-d187-467d-b318-71602a85f9c7</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Top Up</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>82f44485-7295-4056-ba8b-781c0fcae7e0</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/View Total Decisions</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>c6adc619-1430-4119-8fa2-b19531cbf8a5</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/View Average Acceptance Rate</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>9af6018c-46a1-48e3-9b05-821b99b64453</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Decisions</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>56a6c3e0-97fa-4fc1-ad26-e61905681246</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Transactions</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>50cf2686-552b-467f-bd80-e9e2416065b1</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>true</isRun>
      <testCaseId>Test Cases/Dashboard/Integrations</testCaseId>
   </testCaseLink>
   <testCaseLink>
      <guid>1f3050cf-af2d-4395-a46c-b67c0edd63a9</guid>
      <isReuseDriver>false</isReuseDriver>
      <isRun>false</isRun>
      <testCaseId>Test Cases/Dashboard/Settings</testCaseId>
   </testCaseLink>
</TestSuiteEntity>
