import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('Login Test Cases/Login'), [:], FailureHandling.CONTINUE_ON_FAILURE)

//WebUI.click(findTestObject('Page_IzifinDashboardClient/svg_View_bi me-2'), FailureHandling.CONTINUE_ON_FAILURE)
WebUI.click(findTestObject('Page_IzifinDashboardClient/a_View (1)'))

WebUI.verifyElementPresent(findTestObject('View Total Decisions/Page_IzifinDashboardClient/th_ID'), 0)

WebUI.verifyElementPresent(findTestObject('View Total Decisions/Page_IzifinDashboardClient/th_Product Name'), 0)

WebUI.verifyElementPresent(findTestObject('View Total Decisions/Page_IzifinDashboardClient/th_Date  Time'), 0)

WebUI.verifyElementPresent(findTestObject('View Total Decisions/Page_IzifinDashboardClient/th_Decision'), 0)

WebUI.verifyElementPresent(findTestObject('View Total Decisions/Page_IzifinDashboardClient/th_Score'), 0)

WebUI.click(findTestObject('Decisions/Page_IzifinDashboardClient/span_Download reports'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Decisions/Page_IzifinDashboardClient/li_Accept'))

WebUI.click(findTestObject('View Decisions/Page_IzifinDashboardClient/li_Decline'))

WebUI.click(findTestObject('Decisions/Page_IzifinDashboardClient/li_All'))

WebUI.setText(findTestObject('View Decisions/Page_IzifinDashboardClient/input_To_search-input flex-grow-1'), 'carbon', FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Dashboard/Page_IzifinDashboardClient/svg'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Dshbrd View Decisions/Page_IzifinDashboardClient/svg_Items per page_mat-paginator-icon'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Dashboard/Page_IzifinDashboardClient/path'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Decisions/Page_IzifinDashboardClient/svg_Items per page_mat-paginator-icon'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Page_IzifinDashboardClient/span_20'), FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Decisions/Page_IzifinDashboardClient/span_From'))

WebUI.click(findTestObject('Decisions/Page_IzifinDashboardClient/span_MAR 2022'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/div_2021'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/div_DEC'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/div_31'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/span_To'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/span_MAR 2022'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/div_2022'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/div_FEB'))

WebUI.click(findTestObject('View DSC2/Page_IzifinDashboardClient/div_28'))

//Calendar not visible. Talk to Dev.
//WebUI.setText(findTestObject('New Folder/Page_IzifinDashboardClient/input_To_mat-datepicker-input'), '22', FailureHandling.CONTINUE_ON_FAILURE)
//WebUI.click(findTestObject('Dshbrd View Decisions/Page_IzifinDashboardClient/span_To'))
//WebUI.click(findTestObject('Dshbrd View Decisions/Page_IzifinDashboardClient/span_MAR 2022'))
//WebUI.click(findTestObject('Dshbrd View Decisions/Page_IzifinDashboardClient/div_2022'))
//WebUI.click(findTestObject('View Decisions/Page_IzifinDashboardClient/div_JAN'), FailureHandling.CONTINUE_ON_FAILURE)
//WebUI.click(findTestObject('View Total Decisions/Page_IzifinDashboardClient/div_28'), FailureHandling.CONTINUE_ON_FAILURE)
//WebUI.delay(5, FailureHandling.CONTINUE_ON_FAILURE)
WebUI.click(findTestObject('Dashboard/Page_IzifinDashboardClient/a_Dashboard'), FailureHandling.CONTINUE_ON_FAILURE)

