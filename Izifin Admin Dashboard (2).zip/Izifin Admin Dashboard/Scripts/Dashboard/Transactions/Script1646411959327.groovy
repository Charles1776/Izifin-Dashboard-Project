import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('Login Test Cases/Login'), [:], FailureHandling.OPTIONAL)

WebUI.click(findTestObject('Page_IzifinDashboardClient/span_Transactions'))

WebUI.getWindowTitle()

WebUI.verifyElementPresent(findTestObject('Transactions/Page_IzifinDashboardClient/p_Total Debit Transactions'), 0)

WebUI.verifyElementPresent(findTestObject('Transactions/Page_IzifinDashboardClient/p_Total Credit Transactions'), 0)

WebUI.verifyElementPresent(findTestObject('Transactions/Page_IzifinDashboardClient/p_Total Transactions Made'), 0)

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/li_Credit'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/li_Debit'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/li_All'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/span_Download reports'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/span_From'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/button_MAR 2022'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_2021'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_DEC'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_31'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/span_To'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/span_MAR 2022'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_2022'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_FEB'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_28'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/svg_Items per page_mat-paginator-icon'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/div_Items per page_mat-select-arrow ng-tns-c122-45'))

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/span_20'))

WebUI.setText(findTestObject('Transactions/Page_IzifinDashboardClient/input_To_search-input'), 'Oxygen')

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/svg'))

WebUI.verifyTextNotPresent('Nitrogen', false, FailureHandling.CONTINUE_ON_FAILURE)

WebUI.click(findTestObject('Transactions/Page_IzifinDashboardClient/a_Dashboard'))

