import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testng.keyword.TestNGBuiltinKeywords as TestNGKW
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('Login Test Cases/Login'), [:], FailureHandling.OPTIONAL)

WebUI.click(findTestObject('Page_IzifinDashboardClient/span_Settings'))

WebUI.click(findTestObject('Settings General/Page_IzifinDashboardClient/li_Contact'))

WebUI.verifyElementPresent(findTestObject('Settings Contact/Page_IzifinDashboardClient/div_Contact Email'), 0)

WebUI.verifyTextPresent('izifin@support.com', false)

WebUI.verifyElementPresent(findTestObject('Settings Contact/Page_IzifinDashboardClient/div_Our Website'), 0)

WebUI.verifyTextPresent('http://izifin.com', false)

WebUI.verifyAllLinksOnCurrentPageAccessible(false, [])

WebUI.click(findTestObject('Settings General/Page_IzifinDashboardClient/li_User Roles'))

WebUI.verifyElementPresent(findTestObject('Add User/Page_IzifinDashboardClient/th_ID'), 0)

WebUI.verifyElementPresent(findTestObject('Add User/Page_IzifinDashboardClient/th_Name'), 0)

WebUI.verifyElementPresent(findTestObject('Add User/Page_IzifinDashboardClient/th_Email'), 0)

WebUI.verifyElementPresent(findTestObject('Add User/Page_IzifinDashboardClient/th_Role'), 0)

WebUI.verifyElementClickable(findTestObject('Add User/Page_IzifinDashboardClient/span_Admin_options'))

WebUI.click(findTestObject('Add User/Page_IzifinDashboardClient/span_Admin_options'), FailureHandling.OPTIONAL)

WebUI.click(findTestObject('Add1/Page_IzifinDashboardClient/button_Add User'))

WebUI.setText(findTestObject('Add User/Page_IzifinDashboardClient/input_User Full Name_exampleInputEmail1'), 'Jack Sparrow')

WebUI.setText(findTestObject('Add User/Page_IzifinDashboardClient/input_Email_exampleInputEmail1'), 'Jsparrow@gmail.com')

WebUI.click(findTestObject('Add User/Page_IzifinDashboardClient/select_UserOneTwoThree'), FailureHandling.STOP_ON_FAILURE)

WebUI.selectOptionByLabel(findTestObject('Add User/Page_IzifinDashboardClient/select_UserOneTwoThree'), 'Two', false)

WebUI.click(findTestObject('Add User/Page_IzifinDashboardClient/button_Add User'))

WebUI.click(findTestObject('Dashboard/Page_IzifinDashboardClient/span_Cancel'))

WebUI.click(findTestObject('Settings General/Page_IzifinDashboardClient/li_General'))

WebUI.focus(findTestObject('Settings General/Page_IzifinDashboardClient/div_image'), FailureHandling.OPTIONAL)

WebUI.uploadFile(findTestObject('Upload Image/Page_IzifinDashboardClient/input_Change Logo_file-upload'), 'C:\\Users\\Charles\\Pictures\\Enebeli Charles', 
    FailureHandling.OPTIONAL)

WebUI.setEncryptedText(findTestObject('Settings General/Page_IzifinDashboardClient/input_Old Password_izi-input__password ng-untouched ng-pristine ng-invalid'), 
    'VpMdp7NbYZL0S188q3mSdg==')

WebUI.setEncryptedText(findTestObject('Settings General/Page_IzifinDashboardClient/input_New Password_izi-input__password ng-untouched ng-pristine ng-invalid'), 
    '8SQVv/p9jVScEs4/2CZsLw==')

WebUI.setEncryptedText(findTestObject('Settings General/Page_IzifinDashboardClient/input_Confirm Password_izi-input__password ng-untouched ng-pristine ng-invalid'), 
    '8SQVv/p9jVScEs4/2CZsLw==')

WebUI.click(findTestObject('Settings General/Page_IzifinDashboardClient/button_Save Changes'))

